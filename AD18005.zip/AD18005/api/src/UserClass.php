<?php


class UserClass
{
    public $firstName;
    public $lastName;
    public $age;
    public $username;
    public $password;

}